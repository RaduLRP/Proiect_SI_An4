package net.PSK_Vasile2K.smek;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    public static final byte DATA_MANUAL    = 0x01;
    public static final byte DATA_AUTOMATIC = 0x02;
    public static final byte DATA_LIGHT_ON  = 0x03;
    public static final byte DATA_LIGHT_OFF = 0x04;
    public static final byte DATA_INTENSITY = 0x05;

    String address = null;
    BluetoothAdapter myBluetooth = null;
    BluetoothSocket btSocket = null;
    boolean isBtConnected = false;
    UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ((Button)findViewById(R.id.button_on)).setOnClickListener(l -> {
            try {
                btSocket.getOutputStream().write(new byte[]{DATA_LIGHT_ON, (byte)0x00});
                showMessage("Sent ON");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        ((Button)findViewById(R.id.button_off)).setOnClickListener(l -> {
            try {
                btSocket.getOutputStream().write(new byte[]{DATA_LIGHT_OFF, (byte)0x00});
                showMessage("Sent OFF");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        ((Switch)findViewById(R.id.switch_mode)).setOnCheckedChangeListener((comp, isChecked) -> {
            try {
                if(isChecked){
                    btSocket.getOutputStream().write(new byte[]{DATA_AUTOMATIC, (byte)0x00});
                    showMessage("Sent Automatic light");
                }else{
                    btSocket.getOutputStream().write(new byte[]{DATA_MANUAL, (byte)0x00});
                    showMessage("Sent Manual light");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        ((Button)findViewById(R.id.button_setIntensity)).setOnClickListener(l -> {
            try {
                int intensity = ((SeekBar)findViewById(R.id.seekBar_intensity)).getProgress();
                btSocket.getOutputStream().write(new byte[]{DATA_INTENSITY, (byte)intensity});
                showMessage("Sent " + intensity + " light intensity");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        new ConnectBT().execute();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            btSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showMessage(String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
        Log.d("Bluetoother", s);
    }

    private class ConnectBT extends AsyncTask<Void, Void, Void> {
        private boolean ConnectSuccess = true;

        @Override
        protected Void doInBackground (Void... devices) {
            try {
                myBluetooth = BluetoothAdapter.getDefaultAdapter();
                Set<BluetoothDevice> mPairedDevices = myBluetooth.getBondedDevices();
                if (mPairedDevices.size() > 0) {
                    for (BluetoothDevice device : mPairedDevices) {
                        if(device.getName().equals("HC-05")){
                            address = device.getAddress();
                            if (btSocket == null || !isBtConnected) {
                                myBluetooth = BluetoothAdapter.getDefaultAdapter();
                                BluetoothDevice remoteDevice = myBluetooth.getRemoteDevice(address);
                                btSocket = remoteDevice.createInsecureRfcommSocketToServiceRecord(myUUID);
                                btSocket.connect();
                            }
                            break;
                        }
                    }
                }
            } catch (IOException e) {
                ConnectSuccess = false;
            }

            return null;
        }

        @Override
        protected void onPostExecute (Void result) {
            super.onPostExecute(result);

            if (!ConnectSuccess) {
                showMessage("Connection failed successfully!");
                finish();
            } else {
                showMessage("Connected successfully!");
                isBtConnected = true;
            }
        }
    }
}
